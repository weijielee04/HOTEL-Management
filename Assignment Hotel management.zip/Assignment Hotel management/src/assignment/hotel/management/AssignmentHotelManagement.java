
package assignment.hotel.management;


public class AssignmentHotelManagement {

    public static void main(String[] args) {

    }
    
}
